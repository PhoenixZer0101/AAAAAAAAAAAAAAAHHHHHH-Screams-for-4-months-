﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cill_Narain_Hello_World_Again
{
    class Program
    {
        static void Main(string[] args)
        {
            //Cill Narain
            //1/15/2020
            //Purpose : Hello World, the basics of programmming, hopefully this should help me with commenting. Also utlizes Console.WriteLine
            //Using the magical powers of c-w tab X2, Also known as Console.WriteLine, this welcomes the user to the console window!
            Console.WriteLine("Hello World~");
            /*This prints out my name!*/
            Console.WriteLine("Cill Narain!");
            //Since we need to keep the window up, we use Console.Readline to read a line and by extension, keep the window up.
            Console.ReadLine();

        }
    }
}
